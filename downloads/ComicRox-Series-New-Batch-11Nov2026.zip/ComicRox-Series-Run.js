/* Series / Run: isolated local drafts, reviewed covers, full-catalogue duplicate check. */
'use strict';
(()=>{
 if(document.getElementById('seriesRunPane'))return;
 const $s=id=>document.getElementById(id),key='comicrox_series_run_v1';
 const blank=()=>({version:1,common:{series:'',volume:'',publisher:'',issues:'',grade:'',price:'',imageMode:'online'},rows:[],exports:[]});
 let state=blank(),master=null,pool=[],files=[],busy=false,photoRow=null;
 const escape=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const normal=v=>String(v||'').normalize('NFKC').toLowerCase().replace(/&/g,' and ').replace(/[^a-z0-9]+/g,' ').trim();
 function validate(s){
  if(s?.version!==1||!s.common||!Array.isArray(s.rows)||s.rows.length>200||!Array.isArray(s.exports))throw Error('Not a Series / Run backup.');
  for(const field of ['series','volume','publisher','issues','grade','price','imageMode'])if(typeof s.common[field]!=='string')throw Error('Invalid series defaults in backup.');
  const ids=new Set();for(const r of s.rows){if(!r||typeof r.id!=='string'||ids.has(r.id)||!/^\d{1,5}(?:\.\d{1,2})?$/.test(r.issue)||!Array.isArray(r.photos)||r.photos.length>12||!['online','own'].includes(r.imageMode))throw Error('Invalid issue/photo data in backup.');for(const p of r.photos)if(!p||typeof p.path!=='string'||!p.path||typeof p.name!=='string')throw Error('Invalid photo reference in backup.');for(const field of ['grade','price','qty','year','creators','printing','variant','notes','defects','title','description','imageUrl'])if(typeof r[field]!=='string')throw Error('Invalid issue details in backup.');ids.add(r.id);}
  for(const x of s.exports)if(!x.id||!Array.isArray(x.keys)||!Array.isArray(x.skus)||typeof x.csv!=='string'||!['pending','imported','cancelled'].includes(x.status))throw Error('Invalid Series / Run export history.');
  return s;
 }
 try{const old=localStorage.getItem(key);if(old)state=validate(JSON.parse(old));}catch(e){state=blank();state.readError=e.message;}
 function message(id,text){$s(id).textContent=text;}
 function save(){validate(state);localStorage.setItem(key,JSON.stringify(state));}
 function persist(){try{save();}catch(e){message('srStatus','Your draft could not save: '+e.message+'. Download a backup before closing.');}}
 function parseIssues(text){
  const values=[],seen=new Set();for(const token of String(text).trim().split(/[\s,;]+/).filter(Boolean)){
   const t=token.replace(/^#/,'');let parts;
   if(/^\d{1,5}-\d{1,5}$/.test(t)){const [a,b]=t.split('-').map(Number);if(b<a||b-a>199)throw Error('Use ascending ranges of up to 200 issues.');parts=Array.from({length:b-a+1},(_,i)=>String(a+i));}
   else if(/^\d{1,5}(?:\.\d{1,2})?$/.test(t))parts=[t.replace(/^0+(?=\d)/,'')];else throw Error('Use issue numbers separated by commas, e.g. 2, 10, 12 or 20-25.');
   for(const issue of parts){if(!seen.has(issue)){seen.add(issue);values.push(issue);}if(values.length>200)throw Error('Keep each run to 200 issues or fewer.');}
  }if(!values.length)throw Error('Enter at least one issue number.');return values;
 }
 function seriesName(){return state.batchSeries??state.common.series;}
 function volumeName(){return state.batchVolume??state.common.volume;}
 function identity(r){return [normal(seriesName()),normal(volumeName()),r.issue,normal(r.printing),normal(r.variant)].join('|');}
 function makeTitle(r){
  const base=[seriesName()+(volumeName()?' Vol '+volumeName():'')+' #'+r.issue,r.year,state.common.publisher,r.creators,r.printing,r.variant,r.grade].filter(Boolean).join(' ').replace(/\s+/g,' ').trim();
  if(base.length<=80)return base;
  return [seriesName()+(volumeName()?' Vol '+volumeName():'')+' #'+r.issue,r.year,state.common.publisher.replace(/ Comics$/i,''),r.printing,r.variant,r.grade].filter(Boolean).join(' ').replace(/\s+/g,' ').trim();
 }
 function makeDescription(r){
  const facts=[seriesName()+' #'+r.issue,volumeName()?'Series volume: '+volumeName():'',r.year?'Publication year: '+r.year:'',state.common.publisher?'Publisher: '+state.common.publisher:'',r.creators?'Creator / artist: '+r.creators:'',r.printing?'Printing / edition: '+r.printing:'',r.variant?'Variant / cover: '+r.variant:''].filter(Boolean).join('\n');
  return [facts,r.notes,r.grade?'Condition: '+r.grade+'.':'',r.defects?'Condition details: '+r.defects:'',r.imageMode==='online'?'Stock cover image for identification; it does not show the individual copy. Condition is as described above.':'Photos show the actual copy/copies offered. Please examine them for condition.'].filter(Boolean).join('\n\n');
 }
 function imageDisclosure(r){return r.imageMode==='online'?'Stock cover image for identification; it does not show the individual copy. Condition is as described above.':'Photos show the actual copy/copies offered. Please examine them for condition.';}
 function disclosedDescription(r){
  return [String(r.description||'').replace(/Stock cover image for identification; it does not show the individual copy\. Condition is as described above\.|Photos show the actual copy\/copies offered\. Please examine them for condition\./g,'').trim(),imageDisclosure(r)].filter(Boolean).join('\n\n');
 }
 function regenerate(r){if(!r.manualTitle)r.title=makeTitle(r);if(!r.manualDescription)r.description=makeDescription(r);}
 function resetSkipConfirmation(){if($s('srSkipCheckConfirm'))$s('srSkipCheckConfirm').checked=false;}
 function catalogueChecked(){return !$s('srDuplicateModeSkip').checked;}
 function createRows(){
  resetSkipConfirmation();
  if(!state.common.series.trim())throw Error('Enter the series title.');if(state.common.volume.length>30)throw Error('Keep the volume label under 30 characters.');if(state.common.series.length>100)throw Error('Keep the series name under 100 characters.');
  const changed=state.rows.length&&(normal(seriesName())!==normal(state.common.series)||normal(volumeName())!==normal(state.common.volume));
  if(changed&&!confirm('Start a different series/volume? Download a draft backup first if you need this run. Existing issue edits and images will be cleared only from Series / Run.'))return;
  const issues=parseIssues(state.common.issues),old=new Map((changed?[]:state.rows).map(r=>[r.issue,r]));
  if(state.rows.some(r=>!issues.includes(r.issue))&&!confirm('Remove issues no longer in your list? Download a Series / Run backup first if you need those drafts.'))return;
  state.batchSeries=state.common.series.trim();state.batchVolume=state.common.volume.trim();
  state.rows=issues.map(issue=>old.get(issue)||{id:'issue-'+issue,issue,grade:state.common.grade,price:state.common.price,qty:'1',year:'',creators:'',printing:'',variant:'',notes:'',defects:'',imageMode:state.common.imageMode,imageUrl:'',sourceUrl:'',photos:[],imageConfirmed:false,imageSize:0});
  state.rows.forEach(regenerate);persist();render();message('srStatus',state.rows.length+' separate listings created. Next: choose images and review the details in Step 2.');
 }
 function imageUrls(r){return r.imageMode==='online'?[r.imageUrl].filter(Boolean):r.photos.map(p=>p.url).filter(Boolean);}
 function input(r,name,label,type='text'){return '<label>'+label+'<input data-sr-row="'+escape(r.id)+'" data-sr-field="'+name+'" type="'+type+'" '+(type==='number'?'min="0" step="'+(name==='price'?'0.01':'1')+'" ':'')+'value="'+escape(r[name]||'')+'"></label>';}
 function photoCard(r,p,i){
  return '<div class="srPhotoCard"><a href="'+escape(photoUrl(p))+'" target="_blank" rel="noopener"><img data-sr-photo-row="'+escape(r.id)+'" data-sr-photo-position="'+i+'" src="'+escape(photoUrl(p))+'" alt="'+escape(p.displayName||p.name)+'"></a><small>'+(i===0?'MAIN PHOTO':'Photo '+(i+1))+' · '+escape(p.displayName||p.name)+'</small><div><button class="btn secondary" data-sr-photo-row="'+escape(r.id)+'" data-sr-photo-index="'+i+'" data-sr-photo-action="left" '+(i===0?'disabled':'')+'>←</button><button class="btn secondary" data-sr-photo-row="'+escape(r.id)+'" data-sr-photo-index="'+i+'" data-sr-photo-action="right" '+(i===r.photos.length-1?'disabled':'')+'>→</button><button class="btn secondary" data-sr-photo-row="'+escape(r.id)+'" data-sr-photo-index="'+i+'" data-sr-photo-action="remove">Remove</button></div></div>';
 }
 function changePhotoOrder(id,index,kind){
  const r=state.rows.find(r=>r.id===id);if(!r||!Number.isInteger(index)||!r.photos[index])return;
  if(kind==='remove'){r.photos.splice(index,1);r.imageConfirmed=false;}
  else{const target=index+(kind==='left'?-1:1);if(target<0||target>=r.photos.length)return;[r.photos[index],r.photos[target]]=[r.photos[target],r.photos[index]];}
  persist();render();message('srRowStatus-'+id,'Photo order saved. The first photo is the main listing image.');
 }
 async function browseForIssue(id,fileList){
  const r=state.rows.find(r=>r.id===id);if(!r)return;
  if([...fileList].length+r.photos.length>12)throw Error('Keep each issue to 12 photos or fewer. Remove unwanted photos first.');
  const imported=await comicRoxBrowsePhotoFiles(fileList,text=>message('srRowStatus-'+id,text));
  const used=new Set(state.rows.filter(x=>x.id!==id&&x.imageMode==='own').flatMap(x=>x.photos.map(p=>p.path)));
  if(imported.some(p=>used.has(p.path)))throw Error('One of those photos is already assigned to another issue. Check the book before reusing it.');
  r.photos=[...new Map([...r.photos,...imported.map(p=>({...p,url:''}))].map(p=>[p.path,p])).values()];r.imageMode='own';r.imageConfirmed=false;
  regenerate(r);r.description=disclosedDescription(r);persist();render();message('srRowStatus-'+id,imported.length+' photos selected from your laptop. Use arrows to set the main photo, then confirm this issue. Upload used photos in Step 3.');
 }
 function render(){
  const rows=$s('srRows');rows.innerHTML=state.rows.map(r=>'<article class="srIssue" data-sr-card="'+escape(r.id)+'"><h3>'+escape(seriesName())+' #'+escape(r.issue)+'</h3><div class="srGrid">'+input(r,'grade','Condition (your assessment)')+input(r,'price','Price £','number')+input(r,'qty','Copies with this condition','number')+input(r,'year','Issue publication year')+input(r,'printing','Printing / edition (if confirmed)')+input(r,'variant','Variant / cover')+input(r,'creators','Creator / artist (if confirmed)')+input(r,'defects','Defects / condition details')+'</div><label>Image choice <select data-sr-row="'+escape(r.id)+'" data-sr-field="imageMode"><option value="online" '+(r.imageMode==='online'?'selected':'')+'>Online stock cover</option><option value="own" '+(r.imageMode==='own'?'selected':'')+'>My own photos</option></select></label><div class="srImages">'+(r.imageMode==='online'?(r.imageUrl?'<a href="'+escape(/^https:\/\//i.test(r.imageUrl)?r.imageUrl:'#')+'" target="_blank" rel="noopener"><img data-sr-online="'+escape(r.id)+'" src="'+escape(r.imageUrl)+'" alt="Suggested cover for issue '+escape(r.issue)+'"></a>':'<span>No cover selected</span>'):r.photos.map((p,i)=>photoCard(r,p,i)).join(''))+'</div>'+(r.imageMode==='online'?'<button class="btn secondary" data-sr-search="'+escape(r.id)+'">FIND ONLINE COVERS</button><label>Or paste an approved cover image URL<input data-sr-row="'+escape(r.id)+'" data-sr-field="imageUrl" value="'+escape(r.imageUrl)+'" placeholder="https://…"></label><small>Use a representative cover you can use. Check volume, issue, printing and variant; search results may be seller photos. Stock cover use is disclosed in the description.</small>':'<label class="btn secondary filebtn srBrowseLabel">BROWSE LAPTOP PHOTOS<input data-sr-browse-row="'+escape(r.id)+'" type="file" accept="image/jpeg,image/png,image/webp,.jpg,.jpeg,.png,.webp" multiple hidden></label> <button class="btn secondary" data-sr-photos="'+escape(r.id)+'">CHOOSE FROM RECENT PHOTOS</button><p>'+r.photos.length+' photos selected · '+r.photos.filter(p=>p.url).length+' Shopify image links ready</p>')+(r.imageMode==='online'?'<label class="srConfirm"><input type="checkbox" data-sr-row="'+escape(r.id)+'" data-sr-field="imageConfirmed" '+(r.imageConfirmed?'checked':'')+'> I checked these images show the correct issue, volume, printing and variant.</label>':'')+'<div id="srRowStatus-'+escape(r.id)+'" role="status"></div><div id="srCandidates-'+escape(r.id)+'" class="srCandidates"></div><label>eBay title <span data-sr-length="'+escape(r.id)+'">'+String(r.title||'').length+'/80</span><input data-sr-row="'+escape(r.id)+'" data-sr-field="title" value="'+escape(r.title)+'"></label><label>Additional factual selling points<textarea data-sr-row="'+escape(r.id)+'" data-sr-field="notes">'+escape(r.notes)+'</textarea></label><label>Description<textarea rows="7" data-sr-row="'+escape(r.id)+'" data-sr-field="description">'+escape(r.description)+'</textarea></label><button class="btn secondary" data-sr-regenerate="'+escape(r.id)+'">REGENERATE TITLE / DESCRIPTION</button></article>').join('');
  for(const img of rows.querySelectorAll('img[data-sr-photo-row]')){const r=state.rows.find(r=>r.id===img.dataset.srPhotoRow),p=r.photos[Number(img.dataset.srPhotoPosition)];p.imageSize=0;img.onload=()=>{p.imageSize=Math.max(img.naturalWidth,img.naturalHeight);persist();};img.onerror=()=>{p.imageSize=0;persist();};if(img.complete&&img.naturalWidth)img.onload();}
  for(const img of rows.querySelectorAll('[data-sr-online]')){const r=state.rows.find(r=>r.id===img.dataset.srOnline);r.imageSize=0;img.onload=()=>{r.imageSize=Math.max(img.naturalWidth,img.naturalHeight);persist();message('srRowStatus-'+r.id,r.imageSize>=500?'Cover loaded ('+img.naturalWidth+' × '+img.naturalHeight+'). Confirm the edition below.':'Cover is too small: eBay needs at least 500 pixels on the longest side. Use a larger image.');};img.onerror=()=>{r.imageSize=0;persist();message('srRowStatus-'+r.id,'Cover could not load. Choose another image or use your photos.');};if(img.complete&&img.naturalWidth)img.onload();}
  $s('srRowsCount').textContent=state.rows.length+' listings · one per issue. Unknown facts stay blank; prices and condition come from you.';
  renderHistory();
 }
 function updateRow(input){
  const r=state.rows.find(r=>r.id===input.dataset.srRow);if(!r)return;const field=input.dataset.srField;if(['imageMode','imageUrl'].includes(field)&&r[field]===input.value)return;if(['printing','variant'].includes(field))resetSkipConfirmation();r[field]=input.type==='checkbox'?input.checked:input.value;
  if(field==='title')r.manualTitle=true;if(field==='description')r.manualDescription=true;
  if(['imageUrl','imageMode'].includes(field)){r.imageConfirmed=false;r.imageSize=0;regenerate(r);r.description=disclosedDescription(r);persist();render();return;}
  if(!['title','description','imageConfirmed','price','qty'].includes(field)){regenerate(r);const card=input.closest('.srIssue');card.querySelector('[data-sr-field="title"]').value=r.title;card.querySelector('[data-sr-field="description"]').value=r.description;}
  const count=input.closest('.srIssue').querySelector('[data-sr-length]');count.textContent=String(r.title||'').length+'/80';persist();
 }
 async function searchCovers(id){
  const r=state.rows.find(r=>r.id===id);message('srRowStatus-'+id,'Searching online cover suggestions…');
  const data=await api('/api/series-run/covers',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({series:seriesName(),issue:r.issue})});
  if(data.ok!==true||!Array.isArray(data.candidates))throw Error(data.error||'No cover suggestions returned.');
  r.candidates=data.candidates.filter(c=>{try{return new URL(c.imageUrl).protocol==='https:';}catch{return false;}}).slice(0,12);
  $s('srCandidates-'+id).innerHTML=r.candidates.map((c,i)=>'<div><img src="'+escape(c.imageUrl)+'" alt="Cover suggestion"><p>'+escape(c.title)+'</p><button class="btn secondary" data-sr-cover="'+escape(id)+'" data-sr-candidate="'+i+'">USE THIS COVER</button></div>').join('');
  message('srRowStatus-'+id,r.candidates.length?'Choose the exact edition. Nothing is selected automatically.':'No suitable cover suggestions. Paste an approved image URL or choose your photos.');
 }
 function chooseCover(id,index){const r=state.rows.find(r=>r.id===id),c=r.candidates?.[index];if(!c)return;r.imageMode='online';r.imageUrl=c.imageUrl;r.sourceUrl=c.sourceUrl||'';r.imageConfirmed=false;r.imageSize=0;delete r.candidates;regenerate(r);persist();render();}
 async function loadPhotos(){pool=await api('/api/latest?count='+Number($s('srPhotoCount').value));if(!Array.isArray(pool))throw Error('Photo list could not be read.');message('srPhotoStatus',pool.length+' recent photos loaded. Choose photos beside each issue, or match filenames such as Spawn-002-1.jpg.');}
 function openPhotoPicker(id){
  if(!pool.length)throw Error('Click LOAD MY RECENT PHOTOS in Step 2 first.');photoRow=id;const row=state.rows.find(r=>r.id===id);
  $s('srPhotoPicker').hidden=false;$s('srPhotoPickerTitle').textContent='Choose photos for '+seriesName()+' #'+row.issue;
  $s('srPhotoChoices').innerHTML=pool.map((p,i)=>'<label><input type="checkbox" data-sr-photo-index="'+i+'" '+(row.photos.some(x=>x.path===p.path)?'checked':'')+'><img src="'+escape(photoUrl(p))+'" alt="'+escape(p.name)+'"><small>'+escape(p.name)+'</small></label>').join('');$s('srPhotoPicker').scrollIntoView({block:'start',behavior:'smooth'});
 }
 function assignPhotos(){
  const r=state.rows.find(r=>r.id===photoRow);const selected=[...$s('srPhotoChoices').querySelectorAll('input:checked')].map(x=>pool[Number(x.dataset.srPhotoIndex)]);if(!selected.length||selected.length>12)throw Error('Select between 1 and 12 photos for this issue.');
  const used=new Set(state.rows.filter(x=>x.id!==r.id&&x.imageMode==='own').flatMap(x=>x.photos.map(p=>p.path)));if(selected.some(p=>used.has(p.path)))throw Error('A selected photo is already assigned to another issue. Check the grouping.');
  r.photos=selected.map(p=>({...p,url:r.photos.find(old=>old.path===p.path)?.url||''}));r.imageMode='own';r.imageConfirmed=false;regenerate(r);persist();render();$s('srPhotoPicker').hidden=true;$s('srRows').querySelector('[data-sr-card="'+r.id+'"]').scrollIntoView({block:'start'});
 }
 function matchPhotoNames(){
  if(!pool.length)throw Error('Load your recent photos first.');const prefix=normal(seriesName());let count=0;
  for(const r of state.rows){if(r.imageMode!=='own'||r.photos.length)continue;const matching=pool.filter(p=>{const stem=String(p.name).replace(/\.[^.]+$/,'');const m=stem.match(/^(.*?)[ _-]+(\d{1,5}(?:\.\d{1,2})?)[ _-]+(\d+)$/);return m&&normal(m[1])===prefix&&m[2].replace(/^0+(?=\d)/,'')===r.issue;}).sort((a,b)=>Number(a.name.match(/(\d+)\.[^.]+$/)?.[1])-Number(b.name.match(/(\d+)\.[^.]+$/)?.[1]));
   if(matching.length>12)throw Error('More than 12 photos match issue '+r.issue+'. Choose them manually.');if(matching.length){r.photos=matching.map(p=>({...p,url:''}));r.imageConfirmed=false;count++;}}
  persist();render();message('srPhotoStatus',count+' issues matched by filename. Check each group and confirm its edition before export.');
 }
 async function refreshPhotoLinks(where='srPhotoStatus'){
  files=await api('/api/refresh-shopify',{method:'POST'});if(!Array.isArray(files))throw Error('Shopify image links could not be read.');let ready=0,total=0;
  for(const r of state.rows.filter(r=>r.imageMode==='own'))for(const p of r.photos){total++;const found=files.find(f=>normName(f.Alt)===normName(p.name))||files.find(f=>normName(f.Filename)===normName(p.name));if(found?.URL){p.url=found.URL;ready++;}}
  persist();render();message(where,ready+' of '+total+' photo links ready. If Shopify is still processing images, click REFRESH PHOTO LINKS again.');
 }
 async function uploadPhotos(where='srPhotoStatus'){
  const used=state.rows.filter(r=>r.imageMode==='own').flatMap(r=>r.photos),missing=new Map(used.filter(p=>!p.url).map(p=>[p.path,p]));
  if(!used.length)throw Error('Assign your photos to issues first.');
  if(!missing.size){message(where,'All used photos already have Shopify links. No upload needed.');return;}
  if(!confirm('Upload '+missing.size+' used photos to Shopify Files? No products will be created.'))return;
  message(where,'Uploading '+missing.size+' used photos. Keep this page open…');
  try{await api('/api/upload-shopify',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({paths:[...missing.keys()]})});await refreshPhotoLinks(where);}
  catch(e){throw Error(e.message+' If an upload started, refresh photo links before retrying.');}
 }
 function loadMaster(text,name){
  const rows=parseCsv(text.replace(/^\uFEFF/,'')),h=rows[0]||[];for(const n of ['Handle','Title','Variant SKU','Status'])if(!h.includes(n))throw Error('Choose a fresh ALL-products Shopify export. Missing: '+n);
  const products=new Map(),bySku=new Map();for(const row of rows.slice(1)){const handle=row[h.indexOf('Handle')];if(!handle)continue;if(!products.has(handle))products.set(handle,{handle,title:'',skus:new Set(),status:''});const p=products.get(handle);if(row[h.indexOf('Title')])p.title=row[h.indexOf('Title')];if(row[h.indexOf('Status')])p.status=row[h.indexOf('Status')];const sku=String(row[h.indexOf('Variant SKU')]||'').trim().toUpperCase();if(sku){p.skus.add(sku);if(!bySku.has(sku))bySku.set(sku,[]);bySku.get(sku).push(p);}}
  master={at:Date.now(),name,products,bySku};return products.size;
 }
 async function skuFor(r){const hash=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(identity(r)));return 'CR-SR-'+Array.from(new Uint8Array(hash),b=>b.toString(16).padStart(2,'0')).join('').slice(0,20).toUpperCase();}
 function handleFor(r){return slug('comicrox-sr-'+seriesName()+'-vol-'+(volumeName()||'unspecified')+'-issue-'+r.issue+'-'+(r.printing||'unspecified')+'-'+(r.variant||'standard'));}
 async function exportPlan(){
  if(!state.rows.length)throw Error('Create your issue rows first.');const checked=catalogueChecked();if(checked){if(!master||Date.now()-master.at>30*60*1000)throw Error('Load a fresh Shopify ALL-products CSV in Step 3 (within 30 minutes).');if(!$s('srMasterComplete').checked)throw Error('Confirm the Shopify export includes ALL products, including draft and archived.');}else if(!$s('srSkipCheckConfirm').checked)throw Error('Confirm these are new products to export without a Shopify catalogue check.');
  const ready=[],existing=[],held=[],seen=new Set(),pending=new Set(state.exports.filter(x=>x.status==='pending').flatMap(x=>x.keys));
  for(const r of state.rows){const code=await skuFor(r),handle=handleFor(r)+'-'+code.slice(-8).toLowerCase(),id=identity(r),problems=[];if(seen.has(id))throw Error('Duplicate issue / edition identity.');seen.add(id);
   const exact=checked?(master.bySku.get(code)||[]):[];if(exact.length>1){held.push({r,reason:'Duplicate SKU in Shopify — check existing listings'});continue;}
   if(checked&&(exact.length||master.products.has(handle))){existing.push({r,title:exact[0]?.title||master.products.get(handle).title});continue;}
   if(pending.has(id)){held.push({r,reason:'An earlier CSV for this issue is still awaiting its import outcome'});continue;}
   const possible=(checked?[...master.products.values()]:[]).filter(p=>{const title=normal(p.title),series=normal(seriesName());const issue=String(p.title).match(/#\s*(\d+(?:\.\d+)?)/)?.[1];return title===normal(r.title)||(title.startsWith(series+' ')&&issue===r.issue);});
   if(possible.length){held.push({r,reason:'Possible existing issue: '+possible.slice(0,3).map(p=>p.title+' ['+p.status+']').join('; ')});continue;}
   if(!String(r.title||'').trim()||r.title.length>80)problems.push('review title (maximum 80 characters)');if(!String(r.grade||'').trim())problems.push('enter condition');if(!(Number(r.price)>0))problems.push('enter a price');if(!Number.isSafeInteger(Number(r.qty))||Number(r.qty)<1)problems.push('copies must be a positive whole number');if(r.year&&!/^(?:18|19|20)\d{2}$/.test(r.year))problems.push('check issue publication year');
   if(r.imageMode==='online'&&!r.imageConfirmed)problems.push('confirm online cover and edition');const urls=imageUrls(r);if(!urls.length||urls.some(u=>!/^https:\/\//i.test(u)))problems.push('add public HTTPS images');if(r.imageMode==='online'&&r.imageSize<500)problems.push('online image must load and be at least 500 pixels');if(r.imageMode==='own'&&r.photos.some(p=>!(p.imageSize>=500)))problems.push('own photos must load and be at least 500 pixels');if(r.imageMode==='own'&&(!r.photos.length||r.photos.some(p=>!p.url)))problems.push('upload / refresh all assigned photo links');if(!String(r.description||'').trim())problems.push('enter a description');
   if(problems.length)held.push({r,reason:problems.join('; ')});else ready.push({r,sku:code,handle,id});
  }return {ready,existing,held,catalogueChecked:checked};
 }
 function showPlan(plan){message('srExportStatus',plan.ready.length+' ready · '+(plan.catalogueChecked?plan.existing.length+' already in Shopify':'Shopify catalogue check skipped')+' · '+plan.held.length+' held.');$s('srPlan').innerHTML=plan.existing.map(x=>'<p>'+escape(x.r.issue)+' — already in Shopify: '+escape(x.title)+'</p>').join('')+plan.held.map(x=>'<p class="warn">Issue '+escape(x.r.issue)+' — '+escape(x.reason)+'</p>').join('');}
 async function downloadExport(){
  const plan=await exportPlan();showPlan(plan);if(!plan.ready.length)throw Error('No new listings are ready. Resolve the held items or keep them saved for later.');
  if(plan.held.length&&!confirm('Download '+plan.ready.length+' ready listings and keep '+plan.held.length+' held in this draft?'))return;
  const h=['Handle','Title','Body (HTML)','Vendor','Product Category','Type','Tags','Published','Option1 Name','Option1 Value','Variant SKU','Variant Grams','Variant Inventory Tracker','Variant Inventory Qty','Variant Inventory Policy','Variant Fulfillment Service','Variant Price','Variant Requires Shipping','Variant Taxable','Image Src','Image Position','Image Alt Text','Gift Card','Status','Publisher (product.metafields.custom.publisher)'];
  const rows=[];for(const {r,sku,handle}of plan.ready){const urls=imageUrls(r),tags=['comic','comicbook','comics',state.common.publisher,r.year,r.grade].filter(Boolean).join(', ');rows.push([handle,r.title,bodyHtml(disclosedDescription(r)),'ComicRox',CATEGORY,'Comic Books',tags,'True','Title','Default Title',sku,120,'shopify',r.qty,'deny','manual',Number(r.price).toFixed(2),'True','True',urls[0],1,r.title,'False','active',state.common.publisher]);for(let i=1;i<urls.length;i++){const a=Array(h.length).fill('');a[0]=handle;a[19]=urls[i];a[20]=i+1;a[21]=r.title;rows.push(a);}}
  const csv='\ufeff'+[h,...rows].map(row=>row.map(q).join(',')).join('\r\n'),run={id:'SR-'+Date.now(),at:new Date().toISOString(),status:'pending',catalogueChecked:plan.catalogueChecked,keys:plan.ready.map(x=>x.id),skus:plan.ready.map(x=>x.sku),csv};state.exports.push(run);try{save();}catch(e){state.exports.pop();throw Error('Export not downloaded because its history could not save. Download a draft backup first.');}
  dl(new Blob([csv],{type:'text/csv'}),'ComicRox_Series_Run_'+run.id+'.csv');master=null;$s('srMasterComplete').checked=false;resetSkipConfirmation();renderHistory();message('srExportStatus','Downloaded '+plan.ready.length+' NEW listings.'+(plan.catalogueChecked?' Shopify catalogue checked.':' Shopify catalogue check skipped by your choice.')+' Next: import this CSV in Shopify, then record its outcome below. Held rows remain saved. No products or stock have been changed by this tool.');
 }
 function renderHistory(){$s('srHistory').innerHTML=state.exports.slice().reverse().map(x=>'<p><b>'+escape(x.id)+'</b> · '+escape(x.at)+' · '+x.keys.length+' issues · '+escape(x.status)+(x.catalogueChecked===false?' · catalogue check skipped':'')+'<br><button class="btn secondary" data-sr-redownload="'+escape(x.id)+'">DOWNLOAD SAME FILE</button>'+(x.status==='pending'?' <button class="btn secondary" data-sr-outcome="'+escape(x.id)+'" data-sr-status="imported">ALL ROWS IMPORTED</button> <button class="btn secondary" data-sr-outcome="'+escape(x.id)+'" data-sr-status="cancelled">NONE IMPORTED / CANCELLED</button>':'')+'</p>').join('');}
 async function action(where,fn){if(busy)return;busy=true;const controls=[...$s('seriesRunPane').querySelectorAll('button')],disabled=controls.map(x=>x.disabled);controls.forEach(x=>x.disabled=true);try{await fn();}catch(e){message(where,e.message);}finally{busy=false;controls.forEach((x,i)=>x.disabled=disabled[i]);}}
 function showTab(){document.body.classList.add('srSeriesActive');document.querySelectorAll('.tabbtn').forEach(x=>x.classList.toggle('active',x.dataset.tab==='seriesRunPane'));document.querySelectorAll('.tabpane').forEach(x=>x.classList.toggle('active',x.id==='seriesRunPane'));}
 const tab=document.createElement('button');tab.className='tabbtn';tab.dataset.tab='seriesRunPane';tab.textContent='SERIES / RUN';document.querySelector('.tabbtn').parentElement.appendChild(tab);tab.onclick=showTab;document.addEventListener('click',e=>{if(e.target.closest('.tabbtn'))document.body.classList.toggle('srSeriesActive',!!$s('seriesRunPane')?.classList.contains('active'));});
 const pane=document.createElement('div');pane.id='seriesRunPane';pane.className='tabpane';pane.innerHTML=`
 <section class="panel"><h2>1. Choose your series and issues</h2><p>Create a separate listing for each issue. Your Standard and Lunar batches stay separate.</p><div class="srGrid">
 <label>Series title<input id="srSeries" maxlength="100" placeholder="Spawn"></label><label>Volume (optional)<input id="srVolume" placeholder="1"></label><label>Publisher (optional)<input id="srPublisher" placeholder="Image Comics"></label><label>Issue numbers<input id="srIssues" placeholder="2, 10, 12, 22, 26 or 1-20"></label><label>Default condition<input id="srGrade" placeholder="NM, VF/NM…"></label><label>Default price £<input id="srPrice" type="number" min="0" step="0.01"></label><label>Default image choice<select id="srImageMode"><option value="online">Online stock covers</option><option value="own">My own photos</option></select></label></div><button class="btn" id="srBuild">CREATE / UPDATE ISSUE ROWS</button><p id="srStatus" role="status"></p><details><summary>Draft backups</summary><button class="btn secondary" id="srBackup">DOWNLOAD SERIES / RUN BACKUP</button><label>Restore Series / Run backup<input id="srRestore" type="file" accept=".json"></label><p>These drafts save in this browser separately from Standard and Lunar batches.</p></details></section>
 <section class="panel"><h2>2. Choose images and review each issue</h2><p id="srRowsCount"></p><p>Use your own photos to show the actual condition. Online covers are representative images; confirm the exact edition and describe condition yourself. Titles use factual search terms, stay within 80 characters, and do not invent rarity, keys or first appearances.</p><details><summary>My photos — load, assign and upload</summary><label>Recent photos<select id="srPhotoCount"><option>25</option><option>50</option><option>100</option><option selected>200</option></select></label><button class="btn secondary" id="srLoadPhotos">LOAD MY RECENT PHOTOS</button> <button class="btn secondary" id="srMatchNames">MATCH ISSUE FILENAMES</button><p>Optional filenames: Spawn-002-1.jpg, Spawn-002-2.jpg, Spawn-010-1.jpg. Timestamp photos can be chosen manually beside each issue.</p><button class="btn secondary" id="srUploadPhotos">UPLOAD ASSIGNED PHOTOS TO SHOPIFY FILES</button> <button class="btn secondary" id="srRefreshPhotos">REFRESH PHOTO LINKS</button><p id="srPhotoStatus" role="status"></p></details><section id="srPhotoPicker" hidden><h3 id="srPhotoPickerTitle"></h3><div id="srPhotoChoices"></div><button class="btn" id="srAssignPhotos">USE SELECTED PHOTOS</button> <button class="btn secondary" id="srClosePhotos">CLOSE</button></section><div id="srRows"></div></section>
 <section class="panel"><h2>3. Prepare and download new listings</h2><p>Choose whether to check the Shopify catalogue. This exports new listings and does not update existing stock.</p><label class="srChoice"><input type="radio" name="srDuplicateMode" id="srDuplicateModeChecked" value="checked" checked> Check against a Shopify export</label><label class="srChoice"><input type="radio" name="srDuplicateMode" id="srDuplicateModeSkip" value="skip"> Skip Shopify export — I know these are new</label><div id="srSkipCheckPanel" hidden><label class="srConfirm"><input type="checkbox" id="srSkipCheckConfirm"> I confirm these are new products and want to export without checking the Shopify catalogue.</label><p>Photo, title, condition and price checks still apply. Pending downloads remain protected.</p></div><div id="srShopifyCheckInputs"><p>Export ALL products, including draft and archived, and load the CSV below.</p><label class="btn filebtn">LOAD SHOPIFY ALL-PRODUCTS CSV<input id="srMaster" type="file" accept=".csv" hidden></label><label class="srConfirm"><input type="checkbox" id="srMasterComplete"> This export contains ALL products, including draft and archived.</label><p id="srMasterStatus" role="status"></p></div><h3>Upload your used photos</h3><p>Only photos assigned to these books are included. Photos with recorded Shopify links are reused. Your laptop originals stay unchanged.</p><button class="btn" id="srUploadUsedPhotos">UPLOAD USED PHOTOS TO SHOPIFY</button> <button class="btn secondary" id="srRefreshUsedPhotos">REFRESH USED PHOTO LINKS</button><p id="srUsedPhotoStatus" role="status"></p><button class="btn secondary" id="srCheck">CHECK WHAT IS READY</button> <button class="btn" id="srExport">DOWNLOAD READY NEW LISTINGS</button><p id="srExportStatus" role="status"></p><div id="srPlan"></div><details><summary>Import outcomes / downloaded files</summary><p>Import the new CSV into Shopify. Mark complete only after all rows succeeded. For partial success leave pending, load a fresh Shopify export and keep the original file.</p><div id="srHistory"></div></details></section>`;
 document.querySelector('.tabpane').parentElement.insertBefore(pane,document.querySelector('.tabpane').nextSibling);
 document.head.insertAdjacentHTML('beforeend','<style>body.srSeriesActive header{position:static}body.srSeriesActive .tabs{position:static;flex-wrap:wrap}#seriesRunPane,#seriesRunPane .panel,#seriesRunPane .srIssue,#srPhotoPicker{scroll-margin-top:90px}#seriesRunPane .srGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px}#seriesRunPane label{display:block;margin:10px 0}#seriesRunPane input,#seriesRunPane textarea,#seriesRunPane select{box-sizing:border-box;width:100%;padding:9px;background:#171717;color:#fff;border:1px solid #555;border-radius:5px}#seriesRunPane .srConfirm input,#seriesRunPane .srChoice input{width:auto}#seriesRunPane .srChoice{display:flex;align-items:center;gap:8px}#seriesRunPane .srIssue{border:1px solid #42543b;border-radius:8px;padding:18px;margin:18px 0}#seriesRunPane .srImages{display:flex;flex-wrap:wrap;gap:10px}#seriesRunPane .srPhotoCard{max-width:210px;padding:8px;border:1px solid #555;border-radius:6px}#seriesRunPane .srBrowseLabel{display:inline-block}#seriesRunPane .srBrowseLabel input[hidden]{display:none}#seriesRunPane .srImages img{max-width:150px;max-height:220px;margin:5px}#seriesRunPane .srCandidates,#srPhotoChoices{display:flex;flex-wrap:wrap;gap:12px}#seriesRunPane .srCandidates>div,#srPhotoChoices label{max-width:190px;padding:10px;border:1px solid #555}#seriesRunPane .srCandidates img,#srPhotoChoices img{max-width:160px;max-height:220px}#srPhotoChoices input{width:auto}#seriesRunPane button{margin:5px 3px}#seriesRunPane [role=status]{padding:10px 0;color:#d6eecc}#seriesRunPane small{display:block;overflow-wrap:anywhere}#srPhotoPicker{border:2px solid #41ff00;padding:15px}</style>');
 const commonFields={srSeries:'series',srVolume:'volume',srPublisher:'publisher',srIssues:'issues',srGrade:'grade',srPrice:'price',srImageMode:'imageMode'};
 for(const [id,field]of Object.entries(commonFields)){$s(id).value=state.common[field]||'';$s(id).oninput=()=>{state.common[field]=$s(id).value;if(['series','volume','issues'].includes(field))resetSkipConfirmation();state.rows.forEach(regenerate);persist();};$s(id).onchange=()=>{if(!['series','volume','issues'].includes(field)){state.rows.forEach(regenerate);render();}};}
 $s('srBuild').onclick=()=>action('srStatus',createRows);$s('srLoadPhotos').onclick=()=>action('srPhotoStatus',loadPhotos);$s('srMatchNames').onclick=()=>action('srPhotoStatus',matchPhotoNames);$s('srUploadPhotos').onclick=()=>action('srPhotoStatus',uploadPhotos);$s('srRefreshPhotos').onclick=()=>action('srPhotoStatus',refreshPhotoLinks);$s('srAssignPhotos').onclick=()=>action('srPhotoStatus',assignPhotos);$s('srClosePhotos').onclick=()=>{$s('srPhotoPicker').hidden=true;};
 $s('srRows').addEventListener('input',e=>{if(e.target.dataset.srField&&!['imageMode','imageUrl'].includes(e.target.dataset.srField))updateRow(e.target);});$s('srRows').addEventListener('change',e=>{if(['imageMode','imageUrl'].includes(e.target.dataset.srField))updateRow(e.target);});
 $s('srRows').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.srPhotoRow||b.dataset.srSearch||b.dataset.srCover||b.dataset.srPhotos||b.dataset.srRegenerate;action('srRowStatus-'+id,async()=>{if(b.dataset.srPhotoAction){changePhotoOrder(id,Number(b.dataset.srPhotoIndex),b.dataset.srPhotoAction);return;}if(b.dataset.srSearch)await searchCovers(id);if(b.dataset.srCover)chooseCover(id,Number(b.dataset.srCandidate));if(b.dataset.srPhotos)openPhotoPicker(id);if(b.dataset.srRegenerate){const r=state.rows.find(r=>r.id===id);r.manualTitle=false;r.manualDescription=false;regenerate(r);persist();render();}});});
 $s('srRows').addEventListener('change',e=>{if(e.target.dataset.srBrowseRow){const id=e.target.dataset.srBrowseRow,selected=[...e.target.files];if(selected.length)action('srRowStatus-'+id,()=>browseForIssue(id,selected));e.target.value='';}});
 $s('srUploadUsedPhotos').onclick=()=>action('srUsedPhotoStatus',()=>uploadPhotos('srUsedPhotoStatus'));$s('srRefreshUsedPhotos').onclick=()=>action('srUsedPhotoStatus',()=>refreshPhotoLinks('srUsedPhotoStatus'));
 for(const id of ['srDuplicateModeChecked','srDuplicateModeSkip'])$s(id).onchange=()=>{resetSkipConfirmation();$s('srShopifyCheckInputs').hidden=!catalogueChecked();$s('srSkipCheckPanel').hidden=catalogueChecked();message('srExportStatus',catalogueChecked()?'Load a fresh full Shopify export to check for existing listings.':'Tick the confirmation above, then CHECK WHAT IS READY or DOWNLOAD READY NEW LISTINGS.');$s('srPlan').innerHTML='';};
 $s('srMaster').onchange=async e=>{try{master=null;const f=e.target.files[0];if(!f)return;const count=loadMaster(await f.text(),f.name);message('srMasterStatus',count+' Shopify products loaded from '+f.name+'. Confirm ALL products, then check what is ready.');}catch(e){message('srMasterStatus',e.message);}finally{e.target.value='';}};
 $s('srCheck').onclick=()=>action('srExportStatus',async()=>showPlan(await exportPlan()));$s('srExport').onclick=()=>action('srExportStatus',downloadExport);
 $s('srHistory').onclick=e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.srRedownload||b.dataset.srOutcome,x=state.exports.find(x=>x.id===id);if(!x)return;if(b.dataset.srRedownload){dl(new Blob([x.csv],{type:'text/csv'}),'ComicRox_Series_Run_'+x.id+'.csv');return;}if(confirm(b.dataset.srStatus==='imported'?'Confirm ALL rows in this file imported successfully?':'Confirm NONE of the rows were imported? Leave partial successes pending.')){x.status=b.dataset.srStatus;persist();renderHistory();master=null;}};
 $s('srBackup').onclick=()=>dl(new Blob([JSON.stringify(state,null,2)],{type:'application/json'}),'ComicRox-Series-Run-Backup.json');$s('srRestore').onchange=async e=>{try{const f=e.target.files[0];if(!f)return;const next=validate(JSON.parse(await f.text()));if(!confirm('Replace only your Series / Run draft with this backup? Standard and Lunar work are unchanged.'))return;state=next;save();master=null;resetSkipConfirmation();for(const [id,k]of Object.entries(commonFields))$s(id).value=state.common[k]||'';render();message('srStatus','Series / Run draft restored. Load a fresh Shopify export before downloading listings.');}catch(e){message('srStatus',e.message);}finally{e.target.value='';}};
 // One preparation action uploads assigned local photos before building the CSV.
 $s('srExport').textContent='PREPARE SHOPIFY FILE';
 $s('srExport').onclick=()=>action('srExportStatus',async()=>{
  if(catalogueChecked()&&(!master||!$s('srMasterComplete').checked))throw Error('Load your full Shopify export and confirm ALL products first, or choose to skip the catalogue check.');
  if(!catalogueChecked()&&!$s('srSkipCheckConfirm').checked)throw Error('Confirm your choice to skip the Shopify catalogue check first.');
  const missing=state.rows.filter(r=>r.imageMode==='own').flatMap(r=>r.photos).filter(p=>!p.url);
  if(missing.length){await uploadPhotos('srExportStatus');if(state.rows.filter(r=>r.imageMode==='own').flatMap(r=>r.photos).some(p=>!p.url)){message('srExportStatus','Photos are not ready yet. Use PREPARE SHOPIFY FILE again after processing finishes.');return;}}
  await downloadExport();
 });
 const photoTools=document.createElement('div');const photoHeading=$s('srUploadUsedPhotos').previousElementSibling.previousElementSibling;photoHeading.before(photoTools);let photoNode=photoHeading;while(photoNode&&photoNode.id!=='srCheck'){const next=photoNode.nextSibling;photoTools.append(photoNode);photoNode=next;}
 const advanced=document.createElement('details');advanced.innerHTML='<summary>Photo upload and link troubleshooting</summary>';photoTools.before(advanced);advanced.append(photoTools);
 const hint=document.createElement('p');hint.textContent='Next: PREPARE SHOPIFY FILE uploads your assigned laptop photos, checks the books and downloads ready listings. Import that file in Shopify, then record the result below.';$s('srExport').before(hint);

 // Keep the previous draft recoverable when starting another load.
 const previousDraftKey=key+'_previous_draft';
 $s('srBuild').insertAdjacentHTML('beforebegin','<button class="btn secondary" id="srNewBatch">START NEW BATCH</button> <button class="btn secondary" id="srPreviousBatch">REOPEN PREVIOUS DRAFT</button> ');
 function syncDraftControls(){
  for(const [id,field]of Object.entries(commonFields))$s(id).value=state.common[field]||'';
  master=null;pool=[];files=[];photoRow=null;resetSkipConfirmation();
  $s('srMasterComplete').checked=false;$s('srDuplicateModeChecked').checked=true;$s('srDuplicateModeSkip').checked=false;$s('srShopifyCheckInputs').hidden=false;$s('srSkipCheckPanel').hidden=true;$s('srPhotoPicker').hidden=true;
  for(const id of ['srMasterStatus','srPhotoStatus','srUsedPhotoStatus','srExportStatus','srPlan'])$s(id).textContent='';
  render();$s('srSeries').focus();
 }
 $s('srNewBatch').onclick=()=>action('srStatus',async()=>{
  if(state.readError)throw Error('Restore your saved draft before starting another batch.');
  if(state.rows.length&&!confirm('Start a new batch? Your current draft will be saved as the previous draft. Import history and pending-file protections will be kept.'))return;
  const old=state,next=blank();next.exports=state.exports;
  if(old.rows.length)localStorage.setItem(previousDraftKey,JSON.stringify(old));
  state=next;try{save();}catch(e){state=old;throw e;}
  syncDraftControls();message('srStatus','New batch started. Enter the series and issues above. Your previous draft can be reopened; import history has been retained.');
 });
 $s('srPreviousBatch').onclick=()=>action('srStatus',async()=>{
  const raw=localStorage.getItem(previousDraftKey);if(!raw)throw Error('No previous draft has been saved yet.');
  const next=validate(JSON.parse(raw)),old=state;
  if(state.rows.length&&!confirm('Reopen the previous draft? The current draft will take its place so you can switch back.'))return;
  next.exports=[...new Map([...next.exports,...old.exports].map(x=>[x.id,x])).values()];
  if(old.rows.length)localStorage.setItem(previousDraftKey,JSON.stringify(old));
  state=next;try{save();}catch(e){state=old;localStorage.setItem(previousDraftKey,raw);throw e;}
  syncDraftControls();message('srStatus','Previous draft reopened with import history retained.');
 });
 render();if(state.readError)message('srStatus','Stored draft could not be read: '+state.readError+'. Restore a checked Series / Run backup.');
 window.ComicRoxSeriesRunTest={parseIssues,makeTitle,makeDescription,exportPlan,loadMaster,identity,skuFor,getState:()=>JSON.parse(JSON.stringify(state)),getMaster:()=>master};
})();
